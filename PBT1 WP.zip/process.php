<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>RESULT</title>
</head>

<?php
// Retrieve customer details, quantity and payment method. Example as follow: 
$name = $_POST['fullName'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$address = $_POST['address'];

//change string input date to time
$date = isset($_POST['date']) ? strtotime($_POST['date']) : null;
// 'd-m-Y' format
$formattedDate = $date ? date('d-m-Y', $date) : '';

// Retrieve items if the checkbox is selected only!
$laptopQ = isset ($_POST["laptop"]) ? $_POST["quantity1"] : 0;
$pcQ = isset ($_POST["pc"]) ? $_POST["quantity2"] : 0;
$hardriveQ = isset ($_POST["hardrive"]) ? $_POST["quantity3"] : 0;
$mouseQ = isset ($_POST["mouse"]) ? $_POST["quantity4"] : 0;
$bagQ = isset ($_POST["bag"]) ? $_POST["quantity5"] : 0;
$headphoneQ = isset ($_POST["headphone"]) ? $_POST["quantity6"] : 0;

// define variable for quantity (calculation!)
$Q1 = $_POST["quantity1"];
$Q2 = $_POST["quantity2"];
$Q3 = $_POST["quantity3"];
$Q4 = $_POST["quantity4"];
$Q5 = $_POST["quantity5"];
$Q6 = $_POST["quantity6"];

// Retrieve payment method!!
$paymentMethod = $_POST["paymentMethod"];
?>

<header>
    <h1>Welcome to Penang PC-Shop</h1>
    </header>

<body>
    <form id="buyingForm">
        <table>
            <tr>
                <td width="30%">Full Name:</td>
                <td><?php echo $name; ?></td>
            <tr>
                <td>Email:</td>
                <td><?php echo $email?></td>
            </tr>
            <tr>
                <td>Phone Number:</td>
                <td><?php echo $phone?></td>
            </tr>
            <tr>
                <td>Address:</td>
                <td><?php echo $address?></td>
            </tr>
            <tr>
                <td>Date:</td>
                <td><?php echo $formattedDate?></td>
            </tr>
        </table>


        <table>
            <tr>
                <th colspan="4" class="PD">Product Details</th>
            </tr>
            <tr>
                <th>Item name</th>
                <th>Unit Price</th>
                <th>Quantity</th>
                <th>Item Total</th>
            </tr>

            <tr>
            <td>HP Pavilion x360 14 inch 2-in-1 Laptop 14-ek1039TU Silver</td>
            <td>RM 3,999.00</td>
            <td><?php echo $laptopQ ; ?></td>
            <td><?php $sales_laptop = $laptopQ ? $Q1 * 3999 : 0; 
                        echo "RM ", $sales_laptop?></td>
            </tr>

            <tr>
            <td>HP 24 inch All-in-One Desktop PC</td>
            <td>RM 2,599.00</td>
            <td><?php echo $pcQ ; ?></td>
            <td><?php $sales_pc = $pcQ ? $Q2 * 2599 : 0; 
                        echo "RM ", $sales_pc?></td>
            </tr>

            <tr>
            <td>Western Digital My Passport 1TB USB 3.0 External Hard Drives New Design</td>
            <td>RM 239.00</td>
            <td><?php echo $hardriveQ ; ?></td>
            <td><?php $sales_hardrive = $hardriveQ ? $Q3 * 239 : 0; 
                        echo "RM ", $sales_hardrive?></td>
            </tr>

            <tr>
            <td>2.4GHz Mini Wireless Optical Game Mouse / USB Receiver</td>
            <td>RM 25.99</td>
            <td><?php echo $mouseQ ; ?></td>
            <td><?php $sales_mouse = $mouseQ ? $Q4 * 25.99 : 0; 
                        echo "RM ", $sales_mouse?></td>
            </tr>

            <tr>
            <td>Anti Thief Backpack Business Fits for 15.6 inch Laptop USB Charging Water Repellent</td>
            <td>RM 124.00</td>
            <td><?php echo $bagQ ; ?></td>
            <td><?php $sales_bag = $bagQ ? $Q5 * 124 : 0; 
                        echo "RM ", $sales_bag?></td>
            </tr>

            <tr>
            <td>Razer BlackShark V2 Multi-Platform Wired E-Sports Headset</td>
            <td>RM 339.00</td>
            <td><?php echo $headphoneQ ; ?></td>
            <td><?php $sales_headphone = $headphoneQ ? $Q6 * 339 : 0; 
                        echo "RM ", $sales_headphone?></td>
            </tr>

            <br>

            <tr>
                <th colspan = "4" class="PD">Bill</th>
            </tr>

            <tr>
                <td colspan = "2"> Payment Method</td>
                <td colspan = "2"><?php echo $paymentMethod; ?></td>
            </tr>

            <tr>
                <td colspan = "2"> Total Sales</td>
                <td colspan = "2"><?php 
                // Calculate total sales
                $totalSales = $sales_laptop + $sales_pc + $sales_hardrive + $sales_mouse + $sales_bag + $sales_headphone;
                echo "RM ", $totalSales;
                ?></td>
            </tr>

            <tr>
                <td colspan = "2"> Discount 5% (if total sales above RM2000)</td>
                <td colspan = "2"><?php 
                    if ($totalSales > 2000){
                        $discount = round(( $totalSales * 0.05), 2);
                        $disc_price = round(($totalSales - $discount), 2);
                        echo "RM ", $discount;
                    }
                    else {
                        $discount = round(($totalSales * 0.00) , 2);
                        $disc_price = round(($totalSales - $discount), 2);
                        echo "RM ", $discount;
                    }
                ?></td>
            </tr>

            <tr>
                <td colspan = "2"> 6% SST Charged</td>
                <td colspan = "2"><?php 
                    $SST = $disc_price * 0.06;
                    echo "RM ", number_format($SST, 2) ;
                    ?></td>
            </tr>

            <tr>
                <td colspan = "2"> Total Price</td>
                <th class = "PD" colspan = "2"><?php 
                    $finalTotal = $disc_price + $SST ;
                    echo "RM ", number_format($finalTotal, 2) ;
                    ?></th>
            </tr>
        </table>

        <div>
        <input class="button" type="button" onclick="history.back()" value="Back">
        </div>
        
    </form>
 </body>


